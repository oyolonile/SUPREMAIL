import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { useEmailStore } from '../../store/emailStore';
import { formatDate } from '../../lib/utils';

const RecentCampaigns: React.FC = () => {
  const { campaigns } = useEmailStore();
  
  // Sort campaigns by createdAt date (newest first)
  const sortedCampaigns = [...campaigns].sort((a, b) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
  
  // Display only the 5 most recent campaigns
  const recentCampaigns = sortedCampaigns.slice(0, 5);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return <Badge variant="success">Sent</Badge>;
      case 'sending':
        return <Badge variant="primary">Sending</Badge>;
      case 'scheduled':
        return <Badge variant="secondary">Scheduled</Badge>;
      case 'draft':
        return <Badge variant="outline">Draft</Badge>;
      case 'failed':
        return <Badge variant="error">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <CheckCircle className="h-4 w-4 text-success-500" />;
      case 'sending':
        return <Clock className="h-4 w-4 text-primary-500 animate-pulse" />;
      case 'scheduled':
        return <Clock className="h-4 w-4 text-neutral-500" />;
      case 'draft':
        return null;
      case 'failed':
        return <AlertTriangle className="h-4 w-4 text-error-500" />;
      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Recent Campaigns</CardTitle>
        <Link 
          to="/campaigns" 
          className="inline-flex items-center text-sm font-medium text-primary-500 hover:text-primary-600"
        >
          View all
          <ArrowRight className="ml-1 h-4 w-4" />
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentCampaigns.length > 0 ? (
            recentCampaigns.map((campaign) => (
              <div key={campaign.id} className="flex flex-col space-y-2 border-b border-neutral-100 pb-4 last:border-0">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-medium text-neutral-900">{campaign.name}</h3>
                      {getStatusBadge(campaign.status)}
                    </div>
                    <p className="text-sm text-neutral-500">
                      {campaign.subject}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(campaign.status)}
                    <span className="text-sm text-neutral-500">
                      {formatDate(campaign.createdAt)}
                    </span>
                  </div>
                </div>
                
                {campaign.status === 'sent' && (
                  <div className="grid grid-cols-3 gap-4 pt-1">
                    <div className="text-center">
                      <p className="text-xs text-neutral-500">Recipients</p>
                      <p className="text-sm font-medium">{campaign.recipientCount.toLocaleString()}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-neutral-500">Opens</p>
                      <p className="text-sm font-medium">{campaign.openRate}%</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-neutral-500">Clicks</p>
                      <p className="text-sm font-medium">{campaign.clickRate}%</p>
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="py-4 text-center">
              <p className="text-neutral-500">No campaigns yet</p>
              <Link to="/campaigns/new">
                <Button variant="primary" size="sm" className="mt-2">
                  Create Campaign
                </Button>
              </Link>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentCampaigns;