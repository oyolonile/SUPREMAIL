/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#E6F2FC',
          100: '#CCE5F9',
          200: '#99CBF3',
          300: '#66B2ED',
          400: '#3398E7',
          500: '#0078D4', // Primary blue
          600: '#0062AB',
          700: '#004D86',
          800: '#003962',
          900: '#00243D',
        },
        secondary: {
          50: '#E8F5E8',
          100: '#D1EBD1',
          200: '#A3D7A3',
          300: '#75C375',
          400: '#47AF47',
          500: '#107C10', // Secondary green
          600: '#0D640D',
          700: '#0A4D0A',
          800: '#073707',
          900: '#032003',
        },
        accent: {
          50: '#F2EDF7',
          100: '#E5DBEF',
          200: '#CBB7DE',
          300: '#B193CE',
          400: '#976FBD',
          500: '#5C2D91', // Accent purple
          600: '#4A2474',
          700: '#391B59',
          800: '#27133D',
          900: '#150A22',
        },
        success: {
          500: '#107C10', // Same as secondary.500
        },
        warning: {
          500: '#FFB900',
        },
        error: {
          500: '#E81123',
        },
        neutral: {
          50: '#F5F5F5',
          100: '#E6E6E6',
          200: '#CCCCCC',
          300: '#B3B3B3',
          400: '#999999',
          500: '#808080',
          600: '#666666',
          700: '#4D4D4D',
          800: '#333333',
          900: '#1A1A1A',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};