import React, { useState, useEffect } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Save, Send, Image, Link, Bold, Italic, List, ListOrdered, Heading } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import { useEmailStore } from '../../store/emailStore';

interface EmailEditorProps {
  initialSubject?: string;
  initialContent?: string;
  onSave?: (subject: string, content: string) => void;
  onSend?: (subject: string, content: string) => void;
  mode?: 'campaign' | 'template';
}

const EmailEditor: React.FC<EmailEditorProps> = ({
  initialSubject = '',
  initialContent = '',
  onSave,
  onSend,
  mode = 'campaign',
}) => {
  const [subject, setSubject] = useState(initialSubject);
  const [content, setContent] = useState(initialContent);
  const [isSaving, setIsSaving] = useState(false);
  const [isSending, setIsSending] = useState(false);
  
  const { smtpConfigs } = useEmailStore();
  const hasSmtpConfig = smtpConfigs.length > 0;

  useEffect(() => {
    setSubject(initialSubject);
    setContent(initialContent);
  }, [initialSubject, initialContent]);

  const handleSave = () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      if (onSave) {
        onSave(subject, content);
      }
      setIsSaving(false);
    }, 1000);
  };

  const handleSend = () => {
    setIsSending(true);
    
    // Simulate API call
    setTimeout(() => {
      if (onSend) {
        onSend(subject, content);
      }
      setIsSending(false);
    }, 1500);
  };

  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'color': [] }, { 'background': [] }],
      ['link', 'image'],
      ['clean']
    ],
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>
          {mode === 'campaign' ? 'Campaign Editor' : 'Template Editor'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Input
          label="Email Subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Enter your email subject line..."
          required
        />
        
        <div>
          <label className="mb-1.5 block text-sm font-medium text-neutral-700">
            Email Content
          </label>
          <ReactQuill
            value={content}
            onChange={setContent}
            modules={modules}
            placeholder="Compose your email content here..."
            className="rounded-md"
          />
        </div>
        
        {!hasSmtpConfig && mode === 'campaign' && (
          <div className="mt-4 rounded-md bg-yellow-50 p-3 text-sm text-yellow-700">
            <p>
              No SMTP server configured. Please add an SMTP configuration in Settings before sending emails.
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="secondary"
          onClick={handleSave}
          isLoading={isSaving}
          leftIcon={<Save className="mr-2 h-4 w-4" />}
        >
          Save {mode === 'campaign' ? 'Campaign' : 'Template'}
        </Button>
        
        {mode === 'campaign' && (
          <Button
            onClick={handleSend}
            isLoading={isSending}
            disabled={!hasSmtpConfig}
            leftIcon={<Send className="mr-2 h-4 w-4" />}
          >
            Send Campaign
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default EmailEditor;