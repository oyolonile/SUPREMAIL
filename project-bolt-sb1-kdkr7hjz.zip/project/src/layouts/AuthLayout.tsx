import React from 'react';
import { Outlet } from 'react-router-dom';

const AuthLayout: React.FC = () => {
  return (
    <div className="flex min-h-screen flex-col bg-neutral-50">
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="py-4 text-center text-sm text-neutral-500">
        <p>&copy; {new Date().getFullYear()} EmailPro. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AuthLayout;