import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, CheckCircle, Rocket, Shield, BarChart, Users } from 'lucide-react';
import Button from '../components/ui/Button';

const LandingPage: React.FC = () => {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <header className="bg-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Mail className="h-8 w-8 text-primary-500" />
              <span className="ml-2 text-2xl font-bold text-neutral-900">EmailPro</span>
            </div>
            <div className="hidden space-x-6 md:flex">
              <a href="#features" className="text-sm text-neutral-600 hover:text-neutral-900">
                Features
              </a>
              <a href="#pricing" className="text-sm text-neutral-600 hover:text-neutral-900">
                Pricing
              </a>
              <a href="#testimonials" className="text-sm text-neutral-600 hover:text-neutral-900">
                Testimonials
              </a>
            </div>
            <div className="flex items-center space-x-2">
              <Link to="/login">
                <Button variant="ghost" size="sm">
                  Sign in
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="primary" size="sm">
                  Sign up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary-500 to-accent-500 py-20 text-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
              <div className="flex flex-col justify-center">
                <h1 className="mb-6 text-4xl font-bold leading-tight sm:text-5xl">
                  Professional Email Marketing Platform
                </h1>
                <p className="mb-8 text-lg opacity-90">
                  Send high-volume emails, verify links, extract leads, and boost your email marketing effectiveness with our all-in-one platform.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Link to="/register">
                    <Button 
                      className="bg-white text-primary-600 hover:bg-neutral-100" 
                      size="lg"
                    >
                      Start for Free
                    </Button>
                  </Link>
                  <a href="#features">
                    <Button 
                      variant="outline"
                      className="border-white bg-transparent text-white hover:bg-white/10" 
                      size="lg"
                    >
                      Learn More
                    </Button>
                  </a>
                </div>
                <div className="mt-8 flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-white" />
                  <span className="text-sm">Office 365 Integration</span>
                  <CheckCircle className="ml-4 h-5 w-5 text-white" />
                  <span className="text-sm">100K+ Daily Sending</span>
                  <CheckCircle className="ml-4 h-5 w-5 text-white" />
                  <span className="text-sm">Link Verification</span>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative">
                  <div className="absolute inset-0 rounded-xl bg-white opacity-10 blur-xl"></div>
                  <img 
                    src="https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                    alt="Email Marketing Dashboard" 
                    className="relative z-10 w-full max-w-lg rounded-xl shadow-2xl"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold text-neutral-900">Powerful Features</h2>
              <p className="mx-auto max-w-2xl text-neutral-600">
                Our platform provides everything you need for effective email marketing campaigns
              </p>
            </div>

            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
                <div className="mb-4 inline-flex rounded-full bg-primary-100 p-3 text-primary-600">
                  <Mail className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">High-Volume Sending</h3>
                <p className="text-neutral-600">
                  Send up to 100,000 emails daily with our optimized SMTP infrastructure and delivery protocols.
                </p>
              </div>

              <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
                <div className="mb-4 inline-flex rounded-full bg-secondary-100 p-3 text-secondary-600">
                  <Shield className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Link Verification</h3>
                <p className="text-neutral-600">
                  Automatically verify links before sending to ensure deliverability and protect your sender reputation.
                </p>
              </div>

              <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
                <div className="mb-4 inline-flex rounded-full bg-accent-100 p-3 text-accent-600">
                  <Users className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Lead Extraction</h3>
                <p className="text-neutral-600">
                  Extract leads from various sources including websites, text content, and uploaded files.
                </p>
              </div>

              <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
                <div className="mb-4 inline-flex rounded-full bg-warning-100 p-3 text-warning-600">
                  <Rocket className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Office 365 Integration</h3>
                <p className="text-neutral-600">
                  Seamlessly connect with Office 365 for reliable email delivery and contact synchronization.
                </p>
              </div>

              <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
                <div className="mb-4 inline-flex rounded-full bg-error-100 p-3 text-error-600">
                  <BarChart className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Advanced Analytics</h3>
                <p className="text-neutral-600">
                  Track open rates, click-through rates, and other key metrics to optimize your campaigns.
                </p>
              </div>

              <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
                <div className="mb-4 inline-flex rounded-full bg-neutral-100 p-3 text-neutral-600">
                  <CheckCircle className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Easy License Management</h3>
                <p className="text-neutral-600">
                  Simple license key system to manage your subscription and access all premium features.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-primary-50 py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="mb-4 text-3xl font-bold text-neutral-900">Ready to Boost Your Email Marketing?</h2>
            <p className="mx-auto mb-8 max-w-2xl text-neutral-600">
              Join thousands of marketers who are already using our platform to send effective email campaigns.
            </p>
            <Link to="/register">
              <Button size="lg" className="px-8">
                Get Started Today
              </Button>
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
            <div className="space-y-4">
              <div className="flex items-center">
                <Mail className="h-6 w-6 text-primary-500" />
                <span className="ml-2 text-xl font-bold text-neutral-900">EmailPro</span>
              </div>
              <p className="text-sm text-neutral-600">
                Professional email marketing platform with high-volume sending capabilities.
              </p>
            </div>

            <div>
              <h3 className="mb-3 text-sm font-semibold uppercase text-neutral-900">Product</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#features" className="text-sm text-neutral-600 hover:text-primary-500">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="text-sm text-neutral-600 hover:text-primary-500">
                    Pricing
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="mb-3 text-sm font-semibold uppercase text-neutral-900">Company</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#about" className="text-sm text-neutral-600 hover:text-primary-500">
                    About
                  </a>
                </li>
                <li>
                  <a href="#contact" className="text-sm text-neutral-600 hover:text-primary-500">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="mb-3 text-sm font-semibold uppercase text-neutral-900">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#privacy" className="text-sm text-neutral-600 hover:text-primary-500">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#terms" className="text-sm text-neutral-600 hover:text-primary-500">
                    Terms
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 border-t border-neutral-200 pt-8 text-center">
            <p className="text-sm text-neutral-600">
              &copy; {new Date().getFullYear()} EmailPro. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;