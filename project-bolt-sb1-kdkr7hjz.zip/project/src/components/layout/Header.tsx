import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Mail, Bell, Settings, User, LogOut, Menu, X } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import Button from '../ui/Button';
import { getInitials } from '../../lib/utils';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isProfileOpen, setIsProfileOpen] = React.useState(false);
  const { user, logout, isAuthenticated } = useAuthStore();
  const location = useLocation();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleProfile = () => setIsProfileOpen(!isProfileOpen);

  const closeMenus = () => {
    setIsMenuOpen(false);
    setIsProfileOpen(false);
  };

  const handleLogout = () => {
    logout();
    closeMenus();
  };

  return (
    <header className="sticky top-0 z-40 border-b border-neutral-200 bg-white">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center">
          <Link to="/" className="flex items-center space-x-2" onClick={closeMenus}>
            <Mail className="h-6 w-6 text-primary-500" />
            <span className="text-xl font-bold text-neutral-900">EmailPro</span>
          </Link>

          {isAuthenticated && (
            <nav className="ml-8 hidden md:block">
              <ul className="flex space-x-1">
                <li>
                  <Link
                    to="/dashboard"
                    className={`px-3 py-2 text-sm font-medium ${
                      location.pathname === '/dashboard'
                        ? 'text-primary-600'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Dashboard
                  </Link>
                </li>
                <li>
                  <Link
                    to="/campaigns"
                    className={`px-3 py-2 text-sm font-medium ${
                      location.pathname.startsWith('/campaigns')
                        ? 'text-primary-600'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Campaigns
                  </Link>
                </li>
                <li>
                  <Link
                    to="/leads"
                    className={`px-3 py-2 text-sm font-medium ${
                      location.pathname.startsWith('/leads')
                        ? 'text-primary-600'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Leads
                  </Link>
                </li>
                <li>
                  <Link
                    to="/templates"
                    className={`px-3 py-2 text-sm font-medium ${
                      location.pathname.startsWith('/templates')
                        ? 'text-primary-600'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Templates
                  </Link>
                </li>
                <li>
                  <Link
                    to="/tools"
                    className={`px-3 py-2 text-sm font-medium ${
                      location.pathname.startsWith('/tools')
                        ? 'text-primary-600'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Tools
                  </Link>
                </li>
              </ul>
            </nav>
          )}
        </div>

        <div className="flex items-center space-x-4">
          {isAuthenticated ? (
            <>
              <button
                className="hidden rounded-full p-1.5 text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900 md:block"
                aria-label="Notifications"
              >
                <Bell className="h-5 w-5" />
              </button>

              <div className="relative">
                <button
                  className="flex items-center rounded-full text-sm focus:outline-none"
                  onClick={toggleProfile}
                  aria-expanded={isProfileOpen}
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-100 text-sm font-medium text-primary-800">
                    {user?.name ? getInitials(user.name) : 'U'}
                  </div>
                </button>

                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5">
                    <div className="border-b border-neutral-100 px-4 py-2">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-neutral-500">{user?.email}</p>
                    </div>
                    <Link
                      to="/settings"
                      className="flex w-full items-center px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                      onClick={closeMenus}
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </Link>
                    <Link
                      to="/profile"
                      className="flex w-full items-center px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                      onClick={closeMenus}
                    >
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </Link>
                    <button
                      className="flex w-full items-center px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                      onClick={handleLogout}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign out
                    </button>
                  </div>
                )}
              </div>

              <button
                className="rounded-md p-2 text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900 md:hidden"
                onClick={toggleMenu}
                aria-expanded={isMenuOpen}
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </>
          ) : (
            <div className="flex items-center space-x-2">
              <Link to="/login">
                <Button variant="ghost" size="sm">
                  Sign in
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="primary" size="sm">
                  Sign up
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && isAuthenticated && (
        <div className="border-b border-neutral-200 bg-white px-4 py-2 md:hidden">
          <nav>
            <ul className="space-y-1">
              <li>
                <Link
                  to="/dashboard"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname === '/dashboard'
                      ? 'text-primary-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                  onClick={closeMenus}
                >
                  Dashboard
                </Link>
              </li>
              <li>
                <Link
                  to="/campaigns"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname.startsWith('/campaigns')
                      ? 'text-primary-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                  onClick={closeMenus}
                >
                  Campaigns
                </Link>
              </li>
              <li>
                <Link
                  to="/leads"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname.startsWith('/leads')
                      ? 'text-primary-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                  onClick={closeMenus}
                >
                  Leads
                </Link>
              </li>
              <li>
                <Link
                  to="/templates"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname.startsWith('/templates')
                      ? 'text-primary-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                  onClick={closeMenus}
                >
                  Templates
                </Link>
              </li>
              <li>
                <Link
                  to="/tools"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname.startsWith('/tools')
                      ? 'text-primary-600'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                  onClick={closeMenus}
                >
                  Tools
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;