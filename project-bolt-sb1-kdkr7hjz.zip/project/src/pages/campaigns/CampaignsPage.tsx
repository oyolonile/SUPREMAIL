import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, CheckCircle, Clock, AlertTriangle, Plus, Search, Filter } from 'lucide-react';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Badge from '../../components/ui/Badge';
import { useEmailStore } from '../../store/emailStore';
import { formatDate } from '../../lib/utils';

const CampaignsPage: React.FC = () => {
  const { campaigns } = useEmailStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  const filteredCampaigns = campaigns.filter(campaign => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         campaign.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || campaign.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return <Badge variant="success">Sent</Badge>;
      case 'sending':
        return <Badge variant="primary">Sending</Badge>;
      case 'scheduled':
        return <Badge variant="secondary">Scheduled</Badge>;
      case 'draft':
        return <Badge variant="outline">Draft</Badge>;
      case 'failed':
        return <Badge variant="error">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <CheckCircle className="h-4 w-4 text-success-500" />;
      case 'sending':
        return <Clock className="h-4 w-4 text-primary-500 animate-pulse" />;
      case 'scheduled':
        return <Clock className="h-4 w-4 text-neutral-500" />;
      case 'draft':
        return null;
      case 'failed':
        return <AlertTriangle className="h-4 w-4 text-error-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Email Campaigns</h1>
          <p className="text-neutral-600">
            Manage and track all your email marketing campaigns
          </p>
        </div>
        <Link to="/campaigns/new">
          <Button leftIcon={<Plus className="h-4 w-4" />}>
            New Campaign
          </Button>
        </Link>
      </div>

      <div className="mb-6 flex flex-wrap gap-4">
        <div className="flex-1">
          <Input
            placeholder="Search campaigns..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            leftIcon={<Search className="h-4 w-4" />}
          />
        </div>
        
        <div className="w-full sm:w-auto">
          <div className="flex items-center rounded-md border border-neutral-300 bg-white">
            <span className="border-r border-neutral-300 px-3 py-2 text-sm text-neutral-500">
              <Filter className="h-4 w-4" />
            </span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-full rounded-md border-0 bg-transparent px-3 py-2 text-sm focus:ring-0"
            >
              <option value="all">All Status</option>
              <option value="draft">Draft</option>
              <option value="scheduled">Scheduled</option>
              <option value="sending">Sending</option>
              <option value="sent">Sent</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
        <div className="min-w-full divide-y divide-neutral-200">
          <div className="bg-neutral-50 px-6 py-3">
            <div className="grid grid-cols-12 gap-3">
              <div className="col-span-5 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                Campaign
              </div>
              <div className="col-span-2 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                Status
              </div>
              <div className="col-span-2 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                Created
              </div>
              <div className="col-span-2 text-right text-xs font-medium uppercase tracking-wider text-neutral-500">
                Performance
              </div>
              <div className="col-span-1"></div>
            </div>
          </div>
          
          <div className="divide-y divide-neutral-200 bg-white">
            {filteredCampaigns.length > 0 ? (
              filteredCampaigns.map((campaign) => (
                <div key={campaign.id} className="px-6 py-4">
                  <div className="grid grid-cols-12 gap-3">
                    <div className="col-span-5">
                      <p className="font-medium text-neutral-900">{campaign.name}</p>
                      <p className="mt-1 text-sm text-neutral-500">{campaign.subject}</p>
                    </div>
                    <div className="col-span-2 flex items-center">
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(campaign.status)}
                        {getStatusBadge(campaign.status)}
                      </div>
                    </div>
                    <div className="col-span-2 flex items-center text-sm text-neutral-500">
                      {formatDate(campaign.createdAt)}
                    </div>
                    <div className="col-span-2 flex items-center justify-end">
                      {campaign.status === 'sent' ? (
                        <div className="text-right">
                          <p className="text-sm font-medium">
                            {campaign.openRate}% open rate
                          </p>
                          <p className="text-xs text-neutral-500">
                            {campaign.clickRate}% click rate
                          </p>
                        </div>
                      ) : (
                        <span className="text-sm text-neutral-500">-</span>
                      )}
                    </div>
                    <div className="col-span-1 flex items-center justify-end">
                      <Link 
                        to={`/campaigns/${campaign.id}`}
                        className="rounded-full p-2 text-neutral-400 hover:bg-neutral-100 hover:text-neutral-700"
                      >
                        <ChevronRight className="h-5 w-5" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="px-6 py-12 text-center">
                <p className="text-neutral-500">
                  {searchTerm || statusFilter !== 'all'
                    ? 'No campaigns match your search criteria'
                    : 'No campaigns found. Create your first campaign to get started.'}
                </p>
                {!searchTerm && statusFilter === 'all' && (
                  <Link to="/campaigns/new">
                    <Button className="mt-4" variant="primary">
                      Create Campaign
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CampaignsPage;