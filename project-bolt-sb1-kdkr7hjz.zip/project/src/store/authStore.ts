import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AuthState, User } from '../types';
import { MASTER_LICENSE_KEY, validateLicenseKey } from '../lib/utils';

interface AuthStore extends AuthState {
  setUser: (user: User | null) => void;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  validateLicense: (key: string) => boolean;
}

// Demo user for testing
const DEMO_USER: User = {
  id: '1',
  email: 'demo@example.com',
  name: 'Demo User',
  isAdmin: true,
  createdAt: new Date().toISOString(),
};

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      licenseKey: null,
      isValidLicense: false,

      setUser: (user) => set({ 
        user, 
        isAuthenticated: !!user 
      }),

      login: async (email, password) => {
        // In a real app, this would make an API call to authenticate
        if (email === 'demo@example.com' && password === 'password') {
          set({ 
            user: DEMO_USER,
            isAuthenticated: true
          });
          return true;
        }
        return false;
      },

      register: async (name, email, password) => {
        // In a real app, this would make an API call to register
        const newUser: User = {
          id: Math.random().toString(),
          email,
          name,
          isAdmin: false,
          createdAt: new Date().toISOString(),
        };

        set({ 
          user: newUser,
          isAuthenticated: true
        });
        return true;
      },

      logout: () => set({ 
        user: null, 
        isAuthenticated: false,
        // Don't clear the license key on logout
      }),

      validateLicense: (key) => {
        const isValid = validateLicenseKey(key);
        set({ 
          licenseKey: key,
          isValidLicense: isValid
        });
        return isValid;
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);