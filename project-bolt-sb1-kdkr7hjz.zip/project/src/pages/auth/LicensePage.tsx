import React from 'react';
import { Navigate } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import LicenseVerification from '../../components/auth/LicenseVerification';

const LicensePage: React.FC = () => {
  const { isAuthenticated, isValidLicense } = useAuthStore();

  // Redirect if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Redirect if license is already verified
  if (isValidLicense) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-neutral-50">
      <div className="container mx-auto flex flex-1 items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="flex items-center justify-center">
              <Mail className="h-8 w-8 text-primary-500" />
              <h1 className="ml-2 text-2xl font-bold text-neutral-900">EmailPro</h1>
            </div>
            <p className="mt-2 text-neutral-600">
              Verify your license to access all features
            </p>
          </div>

          <LicenseVerification />

          <p className="mt-8 text-center text-xs text-neutral-500">
            Need a license key? Contact our support team or use the master key for demo purposes.
          </p>
        </div>
      </div>
    </div>
  );
};

export default LicensePage;