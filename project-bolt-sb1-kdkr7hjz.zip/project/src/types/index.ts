export interface User {
  id: string;
  email: string;
  name: string;
  isAdmin: boolean;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  licenseKey: string | null;
  isValidLicense: boolean;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface EmailCampaign {
  id: string;
  name: string;
  subject: string;
  content: string;
  status: 'draft' | 'scheduled' | 'sending' | 'sent' | 'failed';
  recipientCount: number;
  openRate: number;
  clickRate: number;
  createdAt: string;
  scheduledAt: string | null;
  sentAt: string | null;
}

export interface SmtpConfig {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  password: string;
  secure: boolean;
  fromEmail: string;
  fromName: string;
  isDefault: boolean;
}

export interface Lead {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  tags: string[];
  source: string;
  createdAt: string;
}

export interface LeadList {
  id: string;
  name: string;
  count: number;
  createdAt: string;
}

export interface LinkVerification {
  url: string;
  isValid: boolean;
  statusCode?: number;
  redirectUrl?: string;
  isBlacklisted?: boolean;
  checkedAt: string;
}