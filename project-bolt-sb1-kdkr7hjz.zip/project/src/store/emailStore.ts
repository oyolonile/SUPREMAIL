import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { EmailCampaign, EmailTemplate, SmtpConfig } from '../types';
import { generateId } from '../lib/utils';

interface EmailStoreState {
  campaigns: EmailCampaign[];
  templates: EmailTemplate[];
  smtpConfigs: SmtpConfig[];
  currentCampaign: EmailCampaign | null;
  currentTemplate: EmailTemplate | null;
}

interface EmailStoreActions {
  addCampaign: (campaign: Omit<EmailCampaign, 'id' | 'createdAt'>) => void;
  updateCampaign: (id: string, updates: Partial<EmailCampaign>) => void;
  deleteCampaign: (id: string) => void;
  setCurrentCampaign: (campaign: EmailCampaign | null) => void;
  
  addTemplate: (template: Omit<EmailTemplate, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTemplate: (id: string, updates: Partial<EmailTemplate>) => void;
  deleteTemplate: (id: string) => void;
  setCurrentTemplate: (template: EmailTemplate | null) => void;
  
  addSmtpConfig: (config: Omit<SmtpConfig, 'id'>) => void;
  updateSmtpConfig: (id: string, updates: Partial<SmtpConfig>) => void;
  deleteSmtpConfig: (id: string) => void;
  setDefaultSmtpConfig: (id: string) => void;
}

// Sample data
const sampleTemplates: EmailTemplate[] = [
  {
    id: '1',
    name: 'Welcome Email',
    subject: 'Welcome to our platform!',
    content: '<h1>Welcome!</h1><p>Thank you for signing up for our service.</p>',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Monthly Newsletter',
    subject: 'Your Monthly Update',
    content: '<h1>Newsletter</h1><p>Here\'s what\'s new this month...</p>',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const sampleCampaigns: EmailCampaign[] = [
  {
    id: '1',
    name: 'Welcome Series',
    subject: 'Welcome to our platform!',
    content: '<h1>Welcome!</h1><p>Thank you for signing up for our service.</p>',
    status: 'sent',
    recipientCount: 1250,
    openRate: 45,
    clickRate: 12,
    createdAt: new Date(Date.now() - 86400000 * 7).toISOString(), // 7 days ago
    scheduledAt: null,
    sentAt: new Date(Date.now() - 86400000 * 6).toISOString(), // 6 days ago
  },
  {
    id: '2',
    name: 'Product Announcement',
    subject: 'Exciting New Features!',
    content: '<h1>New Features!</h1><p>We\'ve added exciting new capabilities...</p>',
    status: 'draft',
    recipientCount: 5000,
    openRate: 0,
    clickRate: 0,
    createdAt: new Date().toISOString(),
    scheduledAt: null,
    sentAt: null,
  },
];

const sampleSmtpConfigs: SmtpConfig[] = [
  {
    id: '1',
    name: 'Office 365',
    host: 'smtp.office365.com',
    port: 587,
    username: 'user@example.com',
    password: '********',
    secure: true,
    fromEmail: 'marketing@example.com',
    fromName: 'Marketing Team',
    isDefault: true,
  },
];

export const useEmailStore = create<EmailStoreState & EmailStoreActions>()(
  persist(
    (set, get) => ({
      campaigns: sampleCampaigns,
      templates: sampleTemplates,
      smtpConfigs: sampleSmtpConfigs,
      currentCampaign: null,
      currentTemplate: null,

      addCampaign: (campaignData) => {
        const newCampaign: EmailCampaign = {
          ...campaignData,
          id: generateId(),
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ campaigns: [...state.campaigns, newCampaign] }));
      },

      updateCampaign: (id, updates) => {
        set((state) => ({
          campaigns: state.campaigns.map((campaign) =>
            campaign.id === id ? { ...campaign, ...updates } : campaign
          ),
        }));
      },

      deleteCampaign: (id) => {
        set((state) => ({
          campaigns: state.campaigns.filter((campaign) => campaign.id !== id),
        }));
      },

      setCurrentCampaign: (campaign) => {
        set({ currentCampaign: campaign });
      },

      addTemplate: (templateData) => {
        const now = new Date().toISOString();
        const newTemplate: EmailTemplate = {
          ...templateData,
          id: generateId(),
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({ templates: [...state.templates, newTemplate] }));
      },

      updateTemplate: (id, updates) => {
        set((state) => ({
          templates: state.templates.map((template) =>
            template.id === id
              ? { ...template, ...updates, updatedAt: new Date().toISOString() }
              : template
          ),
        }));
      },

      deleteTemplate: (id) => {
        set((state) => ({
          templates: state.templates.filter((template) => template.id !== id),
        }));
      },

      setCurrentTemplate: (template) => {
        set({ currentTemplate: template });
      },

      addSmtpConfig: (config) => {
        const newConfig: SmtpConfig = {
          ...config,
          id: generateId(),
        };
        
        // If this is the first config, make it the default
        if (get().smtpConfigs.length === 0) {
          newConfig.isDefault = true;
        }
        
        set((state) => ({ smtpConfigs: [...state.smtpConfigs, newConfig] }));
      },

      updateSmtpConfig: (id, updates) => {
        set((state) => ({
          smtpConfigs: state.smtpConfigs.map((config) =>
            config.id === id ? { ...config, ...updates } : config
          ),
        }));
      },

      deleteSmtpConfig: (id) => {
        const { smtpConfigs } = get();
        const configToDelete = smtpConfigs.find(config => config.id === id);
        
        if (configToDelete && configToDelete.isDefault && smtpConfigs.length > 1) {
          // If deleting the default config, make another one default
          const newDefault = smtpConfigs.find(config => config.id !== id);
          if (newDefault) {
            get().updateSmtpConfig(newDefault.id, { isDefault: true });
          }
        }
        
        set((state) => ({
          smtpConfigs: state.smtpConfigs.filter((config) => config.id !== id),
        }));
      },

      setDefaultSmtpConfig: (id) => {
        set((state) => ({
          smtpConfigs: state.smtpConfigs.map((config) => ({
            ...config,
            isDefault: config.id === id,
          })),
        }));
      },
    }),
    {
      name: 'email-storage',
    }
  )
);