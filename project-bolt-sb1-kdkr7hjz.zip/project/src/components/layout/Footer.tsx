import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Github, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-neutral-200 bg-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Mail className="h-6 w-6 text-primary-500" />
              <span className="text-xl font-bold text-neutral-900">EmailPro</span>
            </div>
            <p className="text-sm text-neutral-600">
              Professional email marketing platform with high-volume sending capabilities, link verification, and lead extraction tools.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-neutral-500 transition-colors hover:text-primary-500"
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-neutral-500 transition-colors hover:text-primary-500"
                aria-label="GitHub"
              >
                <Github className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase text-neutral-900">Product</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/features" className="text-sm text-neutral-600 hover:text-primary-500">
                  Features
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-sm text-neutral-600 hover:text-primary-500">
                  Pricing
                </Link>
              </li>
              <li>
                <Link to="/roadmap" className="text-sm text-neutral-600 hover:text-primary-500">
                  Roadmap
                </Link>
              </li>
              <li>
                <Link to="/changelog" className="text-sm text-neutral-600 hover:text-primary-500">
                  Changelog
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase text-neutral-900">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/docs" className="text-sm text-neutral-600 hover:text-primary-500">
                  Documentation
                </Link>
              </li>
              <li>
                <Link to="/guides" className="text-sm text-neutral-600 hover:text-primary-500">
                  Guides
                </Link>
              </li>
              <li>
                <Link to="/api" className="text-sm text-neutral-600 hover:text-primary-500">
                  API Reference
                </Link>
              </li>
              <li>
                <Link to="/support" className="text-sm text-neutral-600 hover:text-primary-500">
                  Support
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase text-neutral-900">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/privacy" className="text-sm text-neutral-600 hover:text-primary-500">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-sm text-neutral-600 hover:text-primary-500">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/compliance" className="text-sm text-neutral-600 hover:text-primary-500">
                  Email Compliance
                </Link>
              </li>
              <li>
                <Link to="/gdpr" className="text-sm text-neutral-600 hover:text-primary-500">
                  GDPR
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-neutral-200 pt-6">
          <p className="text-center text-sm text-neutral-600">
            &copy; {currentYear} EmailPro. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;