import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';

// Auth Pages
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import LicensePage from './pages/auth/LicensePage';

// Main Pages
import Dashboard from './pages/Dashboard';
import CampaignsPage from './pages/campaigns/CampaignsPage';
import NewCampaignPage from './pages/campaigns/NewCampaignPage';
import ToolsPage from './pages/tools/ToolsPage';
import SettingsPage from './pages/settings/SettingsPage';

// Route Guards
const PrivateRoute = ({ children }: { children: JSX.Element }) => {
  const { isAuthenticated, isValidLicense } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  if (!isValidLicense) {
    return <Navigate to="/license" replace />;
  }
  
  return children;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Auth Routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/license" element={<LicensePage />} />
        </Route>
        
        {/* Main App Routes */}
        <Route element={<MainLayout />}>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          
          <Route
            path="/dashboard"
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            }
          />
          
          <Route
            path="/campaigns"
            element={
              <PrivateRoute>
                <CampaignsPage />
              </PrivateRoute>
            }
          />
          
          <Route
            path="/campaigns/new"
            element={
              <PrivateRoute>
                <NewCampaignPage />
              </PrivateRoute>
            }
          />
          
          <Route
            path="/tools"
            element={
              <PrivateRoute>
                <ToolsPage />
              </PrivateRoute>
            }
          />
          
          <Route
            path="/settings"
            element={
              <PrivateRoute>
                <SettingsPage />
              </PrivateRoute>
            }
          />
        </Route>
        
        {/* Catch-all route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;