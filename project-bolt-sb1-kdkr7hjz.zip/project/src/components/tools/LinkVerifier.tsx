import React, { useState } from 'react';
import { Link2, Check, X, ExternalLink, Loader2 } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';
import Badge from '../ui/Badge';
import { verifyLink } from '../../lib/utils';
import { LinkVerification } from '../../types';

const LinkVerifier: React.FC = () => {
  const [url, setUrl] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<LinkVerification | null>(null);
  const [error, setError] = useState('');
  const [verificationHistory, setVerificationHistory] = useState<LinkVerification[]>([]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      setError('Please enter a URL to verify');
      return;
    }
    
    setError('');
    setIsVerifying(true);
    
    try {
      const result = await verifyLink(url);
      setVerificationResult(result);
      setVerificationHistory(prev => [result, ...prev.slice(0, 9)]);
      setUrl('');
    } catch (err) {
      setError('Failed to verify link. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Link Verifier</CardTitle>
        <CardDescription>
          Verify the validity of links before sending them in your emails
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleVerify} className="mb-6 space-y-4">
          <div className="flex items-end space-x-2">
            <div className="flex-1">
              <Input
                label="URL to verify"
                type="url"
                id="url"
                placeholder="https://example.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                leftIcon={<Link2 className="h-4 w-4" />}
                error={error}
              />
            </div>
            <Button type="submit" isLoading={isVerifying}>
              {isVerifying ? 'Verifying...' : 'Verify Link'}
            </Button>
          </div>
        </form>

        {verificationResult && (
          <div className="mb-6 rounded-lg border p-4">
            <h3 className="mb-3 text-lg font-medium">Verification Result</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-neutral-700">URL:</span>
                <a
                  href={verificationResult.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-sm text-primary-500 hover:text-primary-600"
                >
                  {verificationResult.url}
                  <ExternalLink className="ml-1 h-3 w-3" />
                </a>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-neutral-700">Status:</span>
                {verificationResult.isValid ? (
                  <Badge variant="success" className="flex items-center">
                    <Check className="mr-1 h-3 w-3" />
                    Valid
                  </Badge>
                ) : (
                  <Badge variant="error" className="flex items-center">
                    <X className="mr-1 h-3 w-3" />
                    Invalid
                  </Badge>
                )}
              </div>
              {verificationResult.statusCode && (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-neutral-700">Status Code:</span>
                  <span className="text-sm">{verificationResult.statusCode}</span>
                </div>
              )}
              {verificationResult.redirectUrl && verificationResult.redirectUrl !== verificationResult.url && (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-neutral-700">Redirects To:</span>
                  <a
                    href={verificationResult.redirectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-sm text-primary-500 hover:text-primary-600"
                  >
                    {verificationResult.redirectUrl}
                    <ExternalLink className="ml-1 h-3 w-3" />
                  </a>
                </div>
              )}
              {verificationResult.isBlacklisted !== undefined && (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-neutral-700">Blacklisted:</span>
                  {verificationResult.isBlacklisted ? (
                    <Badge variant="error" className="flex items-center">
                      <X className="mr-1 h-3 w-3" />
                      Yes
                    </Badge>
                  ) : (
                    <Badge variant="success" className="flex items-center">
                      <Check className="mr-1 h-3 w-3" />
                      No
                    </Badge>
                  )}
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-neutral-700">Checked At:</span>
                <span className="text-sm">
                  {new Date(verificationResult.checkedAt).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        )}

        {verificationHistory.length > 0 && (
          <div>
            <h3 className="mb-3 text-lg font-medium">Recent Verifications</h3>
            <div className="overflow-hidden rounded-lg border">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                      URL
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                      Checked At
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 bg-white">
                  {verificationHistory.map((item, index) => (
                    <tr key={index}>
                      <td className="whitespace-nowrap px-6 py-4">
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center text-sm text-primary-500 hover:text-primary-600"
                        >
                          {item.url.length > 30 ? item.url.substring(0, 30) + '...' : item.url}
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4">
                        {item.isValid ? (
                          <Badge variant="success" className="flex items-center">
                            <Check className="mr-1 h-3 w-3" />
                            Valid
                          </Badge>
                        ) : (
                          <Badge variant="error" className="flex items-center">
                            <X className="mr-1 h-3 w-3" />
                            Invalid
                          </Badge>
                        )}
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-neutral-500">
                        {new Date(item.checkedAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default LinkVerifier;