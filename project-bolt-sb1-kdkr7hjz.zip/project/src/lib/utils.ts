import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.slice(0, length) + '...';
}

export const MASTER_LICENSE_KEY = 'EMAILPRO-MASTER-2025-XYZABC';

export function validateLicenseKey(key: string): boolean {
  // For demo purposes, we'll just check if it matches the master key
  return key === MASTER_LICENSE_KEY;
}

export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export function calculatePercentage(value: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((value / total) * 100);
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat().format(num);
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
}

export async function verifyLink(url: string): Promise<LinkVerification> {
  // In a real app, you would make an API call to verify the link
  // This is a mock implementation for demo purposes
  try {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    const isValid = url.startsWith('http') && url.includes('.');
    const statusCode = isValid ? 200 : 404;
    
    return {
      url,
      isValid,
      statusCode,
      redirectUrl: isValid ? url : undefined,
      isBlacklisted: false,
      checkedAt: new Date().toISOString(),
    };
  } catch (error) {
    return {
      url,
      isValid: false,
      checkedAt: new Date().toISOString(),
    };
  }
}

export function extractLeadsFromText(text: string): Lead[] {
  // Simple regex to extract emails from text
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const emails = text.match(emailRegex) || [];
  
  // Remove duplicates
  const uniqueEmails = [...new Set(emails)];
  
  return uniqueEmails.map(email => ({
    id: generateId(),
    email,
    tags: [],
    source: 'Text Import',
    createdAt: new Date().toISOString(),
  }));
}