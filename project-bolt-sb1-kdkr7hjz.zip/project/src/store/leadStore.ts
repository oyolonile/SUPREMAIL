import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Lead, LeadList } from '../types';
import { generateId } from '../lib/utils';

interface LeadStoreState {
  leads: Lead[];
  lists: LeadList[];
  currentList: LeadList | null;
}

interface LeadStoreActions {
  addLead: (lead: Omit<Lead, 'id' | 'createdAt'>) => void;
  addLeads: (leads: Omit<Lead, 'id' | 'createdAt'>[]) => void;
  updateLead: (id: string, updates: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
  
  addList: (name: string) => void;
  updateList: (id: string, name: string) => void;
  deleteList: (id: string) => void;
  setCurrentList: (list: LeadList | null) => void;
  
  addLeadToList: (leadId: string, listId: string) => void;
  removeLeadFromList: (leadId: string, listId: string) => void;
  
  getLeadsByList: (listId: string) => Lead[];
}

// Sample data
const sampleLeads: Lead[] = [
  {
    id: '1',
    email: 'john@example.com',
    firstName: 'John',
    lastName: 'Doe',
    company: 'Acme Inc',
    tags: ['customer', 'active'],
    source: 'Website',
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    email: 'jane@example.com',
    firstName: 'Jane',
    lastName: 'Smith',
    company: 'XYZ Corp',
    tags: ['prospect'],
    source: 'LinkedIn',
    createdAt: new Date().toISOString(),
  },
];

const sampleLists: LeadList[] = [
  {
    id: '1',
    name: 'All Contacts',
    count: 2,
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Newsletter Subscribers',
    count: 1,
    createdAt: new Date().toISOString(),
  },
];

// Map to track which leads belong to which lists
const leadListMap: Record<string, string[]> = {
  '1': ['1', '2'], // All Contacts list contains both leads
  '2': ['1'],      // Newsletter list contains only the first lead
};

export const useLeadStore = create<LeadStoreState & LeadStoreActions>()(
  persist(
    (set, get) => ({
      leads: sampleLeads,
      lists: sampleLists,
      currentList: null,

      addLead: (leadData) => {
        const newLead: Lead = {
          ...leadData,
          id: generateId(),
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ leads: [...state.leads, newLead] }));
        
        // Add to "All Contacts" list if it exists
        const allContactsList = get().lists.find(list => list.name === 'All Contacts');
        if (allContactsList) {
          get().addLeadToList(newLead.id, allContactsList.id);
        }
      },

      addLeads: (leadsData) => {
        const newLeads = leadsData.map(leadData => ({
          ...leadData,
          id: generateId(),
          createdAt: new Date().toISOString(),
        }));
        
        set((state) => ({ leads: [...state.leads, ...newLeads] }));
        
        // Add all new leads to "All Contacts" list if it exists
        const allContactsList = get().lists.find(list => list.name === 'All Contacts');
        if (allContactsList) {
          newLeads.forEach(lead => {
            get().addLeadToList(lead.id, allContactsList.id);
          });
        }
      },

      updateLead: (id, updates) => {
        set((state) => ({
          leads: state.leads.map((lead) =>
            lead.id === id ? { ...lead, ...updates } : lead
          ),
        }));
      },

      deleteLead: (id) => {
        set((state) => ({
          leads: state.leads.filter((lead) => lead.id !== id),
        }));
        
        // Remove from all lists
        Object.keys(leadListMap).forEach(listId => {
          get().removeLeadFromList(id, listId);
        });
      },

      addList: (name) => {
        const newList: LeadList = {
          id: generateId(),
          name,
          count: 0,
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ lists: [...state.lists, newList] }));
        leadListMap[newList.id] = [];
      },

      updateList: (id, name) => {
        set((state) => ({
          lists: state.lists.map((list) =>
            list.id === id ? { ...list, name } : list
          ),
        }));
      },

      deleteList: (id) => {
        set((state) => ({
          lists: state.lists.filter((list) => list.id !== id),
        }));
        delete leadListMap[id];
      },

      setCurrentList: (list) => {
        set({ currentList: list });
      },

      addLeadToList: (leadId, listId) => {
        if (!leadListMap[listId]) {
          leadListMap[listId] = [];
        }
        
        if (!leadListMap[listId].includes(leadId)) {
          leadListMap[listId].push(leadId);
          
          // Update the count in the list
          set((state) => ({
            lists: state.lists.map((list) =>
              list.id === listId ? { ...list, count: list.count + 1 } : list
            ),
          }));
        }
      },

      removeLeadFromList: (leadId, listId) => {
        if (leadListMap[listId] && leadListMap[listId].includes(leadId)) {
          leadListMap[listId] = leadListMap[listId].filter(id => id !== leadId);
          
          // Update the count in the list
          set((state) => ({
            lists: state.lists.map((list) =>
              list.id === listId ? { ...list, count: Math.max(0, list.count - 1) } : list
            ),
          }));
        }
      },

      getLeadsByList: (listId) => {
        const leadIds = leadListMap[listId] || [];
        return get().leads.filter(lead => leadIds.includes(lead.id));
      },
    }),
    {
      name: 'lead-storage',
    }
  )
);