import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import EmailEditor from '../../components/email/EmailEditor';
import { useEmailStore } from '../../store/emailStore';

const NewCampaignPage: React.FC = () => {
  const navigate = useNavigate();
  const { addCampaign } = useEmailStore();
  const [isSuccess, setIsSuccess] = useState(false);
  
  const handleSave = (subject: string, content: string) => {
    addCampaign({
      name: subject, // Using subject as name for simplicity
      subject,
      content,
      status: 'draft',
      recipientCount: 0,
      openRate: 0,
      clickRate: 0,
      scheduledAt: null,
      sentAt: null,
    });
    
    setIsSuccess(true);
    
    // Redirect to campaigns page after successful save
    setTimeout(() => {
      navigate('/campaigns');
    }, 1500);
  };
  
  const handleSend = (subject: string, content: string) => {
    const now = new Date().toISOString();
    
    addCampaign({
      name: subject, // Using subject as name for simplicity
      subject,
      content,
      status: 'sent',
      recipientCount: Math.floor(Math.random() * 1000) + 500, // Random recipient count for demo
      openRate: Math.floor(Math.random() * 60) + 20, // Random open rate for demo
      clickRate: Math.floor(Math.random() * 40) + 5, // Random click rate for demo
      scheduledAt: null,
      sentAt: now,
    });
    
    setIsSuccess(true);
    
    // Redirect to campaigns page after successful send
    setTimeout(() => {
      navigate('/campaigns');
    }, 1500);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900">Create New Campaign</h1>
        <p className="text-neutral-600">
          Compose and send a new email marketing campaign
        </p>
      </div>
      
      {isSuccess ? (
        <div className="rounded-lg border border-success-200 bg-success-50 p-4 text-success-700">
          <p className="text-center text-lg font-medium">Campaign created successfully!</p>
          <p className="text-center">Redirecting to campaigns page...</p>
        </div>
      ) : (
        <EmailEditor 
          mode="campaign"
          onSave={handleSave}
          onSend={handleSend}
        />
      )}
    </div>
  );
};

export default NewCampaignPage;