import React from 'react';
import LinkVerifier from '../../components/tools/LinkVerifier';
import LeadExtractor from '../../components/tools/LeadExtractor';

const ToolsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900">Email Marketing Tools</h1>
        <p className="text-neutral-600">
          Powerful utilities to enhance your email marketing workflow
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <div>
          <LinkVerifier />
        </div>
        <div>
          <LeadExtractor />
        </div>
      </div>
    </div>
  );
};

export default ToolsPage;