import React, { useState } from 'react';
import { Server, Mail, Lock, Key, Plus, Check, Trash2 } from 'lucide-react';
import { useEmailStore } from '../../store/emailStore';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';
import Badge from '../ui/Badge';
import { SmtpConfig } from '../../types';

const SmtpSettings: React.FC = () => {
  const { smtpConfigs, addSmtpConfig, updateSmtpConfig, deleteSmtpConfig, setDefaultSmtpConfig } = useEmailStore();
  
  const [isAdding, setIsAdding] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const [newConfig, setNewConfig] = useState<Omit<SmtpConfig, 'id'>>({
    name: '',
    host: '',
    port: 587,
    username: '',
    password: '',
    secure: true,
    fromEmail: '',
    fromName: '',
    isDefault: false,
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setNewConfig({
      ...newConfig,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  const handleAddConfig = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!newConfig.name || !newConfig.host || !newConfig.username || !newConfig.password || !newConfig.fromEmail) {
      return;
    }
    
    addSmtpConfig(newConfig);
    
    // Show success message
    setSuccessMessage('SMTP configuration added successfully');
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
    
    // Reset form
    setNewConfig({
      name: '',
      host: '',
      port: 587,
      username: '',
      password: '',
      secure: true,
      fromEmail: '',
      fromName: '',
      isDefault: false,
    });
    
    // Close add form
    setIsAdding(false);
  };
  
  const handleSetDefault = (id: string) => {
    setDefaultSmtpConfig(id);
    
    // Show success message
    setSuccessMessage('Default SMTP configuration updated');
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };
  
  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this SMTP configuration?')) {
      deleteSmtpConfig(id);
      
      // Show success message
      setSuccessMessage('SMTP configuration deleted');
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>SMTP Settings</CardTitle>
            <CardDescription>
              Configure your email sending servers for high-volume delivery
            </CardDescription>
          </div>
          <Button 
            onClick={() => setIsAdding(!isAdding)} 
            size="sm"
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add SMTP
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {showSuccess && (
          <div className="mb-4 flex items-center rounded-md bg-success-50 p-3 text-sm text-success-700">
            <Check className="mr-2 h-5 w-5" />
            <span>{successMessage}</span>
          </div>
        )}
        
        {isAdding && (
          <form onSubmit={handleAddConfig} className="mb-6 rounded-md border border-neutral-200 p-4">
            <h3 className="mb-4 text-lg font-medium">Add SMTP Configuration</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Input
                label="Configuration Name"
                name="name"
                value={newConfig.name}
                onChange={handleInputChange}
                placeholder="e.g., Office 365 Main"
                required
              />
              
              <Input
                label="SMTP Host"
                name="host"
                value={newConfig.host}
                onChange={handleInputChange}
                placeholder="e.g., smtp.office365.com"
                required
                leftIcon={<Server className="h-4 w-4" />}
              />
              
              <Input
                label="Port"
                name="port"
                type="number"
                value={newConfig.port}
                onChange={handleInputChange}
                placeholder="587"
                required
              />
              
              <Input
                label="Username"
                name="username"
                value={newConfig.username}
                onChange={handleInputChange}
                placeholder="your@email.com"
                required
                leftIcon={<Mail className="h-4 w-4" />}
              />
              
              <Input
                label="Password"
                name="password"
                type="password"
                value={newConfig.password}
                onChange={handleInputChange}
                placeholder="********"
                required
                leftIcon={<Lock className="h-4 w-4" />}
              />
              
              <Input
                label="From Email"
                name="fromEmail"
                value={newConfig.fromEmail}
                onChange={handleInputChange}
                placeholder="sender@yourdomain.com"
                required
                leftIcon={<Mail className="h-4 w-4" />}
              />
              
              <Input
                label="From Name"
                name="fromName"
                value={newConfig.fromName}
                onChange={handleInputChange}
                placeholder="Your Company"
                required
              />
              
              <div className="flex items-center space-x-2 sm:col-span-2">
                <input
                  type="checkbox"
                  id="secure"
                  name="secure"
                  checked={newConfig.secure}
                  onChange={handleInputChange}
                  className="h-4 w-4 rounded border-neutral-300 text-primary-500 focus:ring-primary-500"
                />
                <label htmlFor="secure" className="text-sm text-neutral-700">
                  Use Secure Connection (TLS/SSL)
                </label>
              </div>
            </div>
            
            <div className="mt-4 flex space-x-2">
              <Button type="submit">
                Save Configuration
              </Button>
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => setIsAdding(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        )}
        
        {smtpConfigs.length > 0 ? (
          <div className="overflow-hidden rounded-lg border">
            <table className="min-w-full divide-y divide-neutral-200">
              <thead className="bg-neutral-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                    Host
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                    From Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                    Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium uppercase tracking-wider text-neutral-500">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 bg-white">
                {smtpConfigs.map((config) => (
                  <tr key={config.id}>
                    <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-neutral-900">
                      {config.name}
                      {config.isDefault && (
                        <Badge variant="success" className="ml-2">
                          Default
                        </Badge>
                      )}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-neutral-500">
                      {config.host}:{config.port}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-neutral-500">
                      {config.fromEmail}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm">
                      <Badge variant="primary">
                        {config.secure ? 'Secure' : 'Insecure'}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-right text-sm font-medium">
                      {!config.isDefault && (
                        <button
                          onClick={() => handleSetDefault(config.id)}
                          className="mr-2 text-primary-500 hover:text-primary-700"
                        >
                          Set Default
                        </button>
                      )}
                      <button
                        onClick={() => handleDelete(config.id)}
                        className="text-error-500 hover:text-error-700"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="rounded-md border border-dashed border-neutral-300 p-8 text-center">
            <Server className="mx-auto h-12 w-12 text-neutral-400" />
            <h3 className="mt-2 text-lg font-medium text-neutral-900">No SMTP Servers Configured</h3>
            <p className="mt-1 text-sm text-neutral-500">
              Add your first SMTP server configuration to start sending emails.
            </p>
            <Button 
              onClick={() => setIsAdding(true)} 
              className="mt-4"
              leftIcon={<Plus className="mr-2 h-4 w-4" />}
            >
              Add SMTP Server
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SmtpSettings;