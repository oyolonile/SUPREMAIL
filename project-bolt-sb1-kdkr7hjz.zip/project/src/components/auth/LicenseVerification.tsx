import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Key, CheckCircle, XCircle } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';
import { MASTER_LICENSE_KEY } from '../../lib/utils';

const LicenseVerification: React.FC = () => {
  const [licenseKey, setLicenseKey] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const navigate = useNavigate();
  const { validateLicense } = useAuthStore();

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      const isValid = validateLicense(licenseKey);
      
      if (isValid) {
        setIsSuccess(true);
        setTimeout(() => {
          navigate('/dashboard');
        }, 1500);
      } else {
        setError('Invalid license key. Please try again.');
      }
      
      setIsVerifying(false);
    }, 1000);
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Verify Your License</CardTitle>
        <CardDescription>
          Enter your license key to access EmailPro
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isSuccess ? (
          <div className="flex flex-col items-center justify-center space-y-4 py-4">
            <CheckCircle className="h-16 w-16 text-success-500" />
            <p className="text-center text-lg font-medium text-success-500">License verified successfully!</p>
            <p className="text-center text-sm text-neutral-600">Redirecting to dashboard...</p>
          </div>
        ) : (
          <form onSubmit={handleVerify} className="space-y-4">
            {error && (
              <div className="rounded-md bg-error-50 p-3 text-sm text-error-500">
                <div className="flex items-center space-x-2">
                  <XCircle className="h-5 w-5" />
                  <p>{error}</p>
                </div>
              </div>
            )}

            <Input
              label="License Key"
              type="text"
              id="license-key"
              placeholder="Enter your license key"
              value={licenseKey}
              onChange={(e) => setLicenseKey(e.target.value)}
              required
              leftIcon={<Key className="h-4 w-4" />}
            />

            <p className="text-xs text-neutral-500">
              For demo, use license key: {MASTER_LICENSE_KEY}
            </p>

            <Button type="submit" className="w-full" isLoading={isVerifying}>
              Verify License
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
};

export default LicenseVerification;