import React from 'react';
import Stats from '../components/dashboard/Stats';
import RecentCampaigns from '../components/dashboard/RecentCampaigns';
import ChartStats from '../components/dashboard/ChartStats';

const Dashboard: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-900">Dashboard</h1>
        <p className="text-neutral-600">
          Welcome to your email marketing dashboard
        </p>
      </div>

      <div className="mb-8">
        <Stats />
      </div>

      <div className="mb-8">
        <ChartStats />
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <RecentCampaigns />
        </div>
        <div>
          <div className="rounded-lg border border-neutral-200 bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-medium">Quick Actions</h2>
            <div className="space-y-2">
              <a
                href="/campaigns/new"
                className="flex items-center rounded-md border border-primary-300 bg-primary-50 px-4 py-3 text-sm font-medium text-primary-700 transition-colors hover:bg-primary-100"
              >
                Create New Campaign
              </a>
              <a
                href="/leads/import"
                className="flex items-center rounded-md border border-neutral-300 bg-white px-4 py-3 text-sm font-medium text-neutral-700 transition-colors hover:bg-neutral-50"
              >
                Import Leads
              </a>
              <a
                href="/templates"
                className="flex items-center rounded-md border border-neutral-300 bg-white px-4 py-3 text-sm font-medium text-neutral-700 transition-colors hover:bg-neutral-50"
              >
                Manage Templates
              </a>
              <a
                href="/tools"
                className="flex items-center rounded-md border border-neutral-300 bg-white px-4 py-3 text-sm font-medium text-neutral-700 transition-colors hover:bg-neutral-50"
              >
                Access Tools
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;