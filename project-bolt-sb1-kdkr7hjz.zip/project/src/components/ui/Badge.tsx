import React from 'react';
import { cn } from '../../lib/utils';

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'outline';
}

const Badge = ({ className, variant = 'primary', ...props }: BadgeProps) => {
  const variants = {
    primary: 'bg-primary-50 text-primary-700 ring-1 ring-inset ring-primary-600/20',
    secondary: 'bg-neutral-50 text-neutral-700 ring-1 ring-inset ring-neutral-600/20',
    success: 'bg-green-50 text-green-700 ring-1 ring-inset ring-green-600/20',
    warning: 'bg-yellow-50 text-yellow-700 ring-1 ring-inset ring-yellow-600/20',
    error: 'bg-red-50 text-red-700 ring-1 ring-inset ring-red-600/20',
    outline: 'bg-transparent text-neutral-700 ring-1 ring-inset ring-neutral-300',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center rounded-md px-2 py-1 text-xs font-medium',
        variants[variant],
        className
      )}
      {...props}
    />
  );
};

export default Badge;