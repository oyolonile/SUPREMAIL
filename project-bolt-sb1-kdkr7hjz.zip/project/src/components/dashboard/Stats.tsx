import React from 'react';
import { Mail, Users, Send, LineChart, ArrowUp, ArrowDown } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';

interface StatCardProps {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, change, icon }) => {
  const isPositive = change >= 0;
  
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium text-neutral-500">{title}</p>
            <p className="text-2xl font-semibold text-neutral-900">{value}</p>
          </div>
          <div className="rounded-full bg-primary-50 p-3 text-primary-500">
            {icon}
          </div>
        </div>
        <div className="mt-2 flex items-center">
          <span className={`flex items-center text-sm ${isPositive ? 'text-success-500' : 'text-error-500'}`}>
            {isPositive ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />}
            {Math.abs(change)}%
          </span>
          <span className="ml-1 text-xs text-neutral-500">vs. last month</span>
        </div>
      </CardContent>
    </Card>
  );
};

const Stats: React.FC = () => {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Total Campaigns"
        value="24"
        change={12}
        icon={<Mail className="h-6 w-6" />}
      />
      <StatCard
        title="Total Leads"
        value="14,532"
        change={8.5}
        icon={<Users className="h-6 w-6" />}
      />
      <StatCard
        title="Emails Sent"
        value="142,857"
        change={32.4}
        icon={<Send className="h-6 w-6" />}
      />
      <StatCard
        title="Avg. Open Rate"
        value="38.2%"
        change={-2.1}
        icon={<LineChart className="h-6 w-6" />}
      />
    </div>
  );
};

export default Stats;