import React from 'react';
import SmtpSettings from '../../components/email/SmtpSettings';

const SettingsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900">Settings</h1>
        <p className="text-neutral-600">
          Configure your email marketing platform
        </p>
      </div>
      
      <div className="space-y-8">
        <SmtpSettings />
      </div>
    </div>
  );
};

export default SettingsPage;