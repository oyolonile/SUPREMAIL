import React, { useState } from 'react';
import { Users, Download, Upload, FileText, Check } from 'lucide-react';
import Button from '../ui/Button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';
import Badge from '../ui/Badge';
import { extractLeadsFromText } from '../../lib/utils';
import { useLeadStore } from '../../store/leadStore';
import { Lead } from '../../types';

const LeadExtractor: React.FC = () => {
  const [text, setText] = useState('');
  const [extractedLeads, setExtractedLeads] = useState<Lead[]>([]);
  const [isExtracting, setIsExtracting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const { addLeads } = useLeadStore();

  const handleExtract = () => {
    if (!text) return;
    
    setIsExtracting(true);
    
    setTimeout(() => {
      const leads = extractLeadsFromText(text);
      setExtractedLeads(leads);
      setIsExtracting(false);
    }, 1000);
  };

  const handleAddToLeads = () => {
    if (extractedLeads.length === 0) return;
    
    addLeads(extractedLeads);
    setShowSuccess(true);
    
    setTimeout(() => {
      setShowSuccess(false);
    }, 3000);
  };

  const handleClear = () => {
    setText('');
    setExtractedLeads([]);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Lead Extractor</CardTitle>
        <CardDescription>
          Extract email addresses from text, websites, or uploaded files
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4 space-y-2">
          <label htmlFor="text-input" className="block text-sm font-medium text-neutral-700">
            Paste text containing email addresses
          </label>
          <textarea
            id="text-input"
            className="w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
            rows={8}
            placeholder="Paste text, website content, or document text here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        </div>

        <div className="mb-6 flex flex-wrap gap-2">
          <Button 
            onClick={handleExtract} 
            isLoading={isExtracting}
            leftIcon={<Users className="mr-2 h-4 w-4" />}
          >
            Extract Leads
          </Button>
          
          <Button 
            variant="secondary" 
            onClick={handleClear}
            leftIcon={<FileText className="mr-2 h-4 w-4" />}
          >
            Clear
          </Button>
          
          {extractedLeads.length > 0 && (
            <Button 
              variant="success" 
              onClick={handleAddToLeads}
              leftIcon={<Download className="mr-2 h-4 w-4" />}
            >
              Add to Leads
            </Button>
          )}
        </div>

        {showSuccess && (
          <div className="mb-4 flex items-center rounded-md bg-success-50 p-3 text-sm text-success-700">
            <Check className="mr-2 h-5 w-5" />
            <span>Successfully added {extractedLeads.length} leads to your contacts.</span>
          </div>
        )}

        {extractedLeads.length > 0 && (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-lg font-medium">Extracted Leads</h3>
              <Badge variant="primary">{extractedLeads.length} found</Badge>
            </div>
            
            <div className="max-h-60 overflow-y-auto rounded-md border border-neutral-200">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500">
                      Source
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 bg-white">
                  {extractedLeads.map((lead) => (
                    <tr key={lead.id}>
                      <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-neutral-900">
                        {lead.email}
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-neutral-500">
                        {lead.source}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default LeadExtractor;