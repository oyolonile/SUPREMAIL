import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const ChartStats: React.FC = () => {
  // Last 7 days data
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  // Email stats line chart
  const emailStatsOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
    interaction: {
      mode: 'nearest' as const,
      axis: 'x' as const,
      intersect: false,
    },
    maintainAspectRatio: false,
  };

  const emailStatsData = {
    labels: days,
    datasets: [
      {
        label: 'Sent',
        data: [12500, 18700, 15200, 22400, 19800, 8300, 6100],
        borderColor: '#0078D4',
        backgroundColor: 'rgba(0, 120, 212, 0.1)',
        fill: true,
        tension: 0.4,
      },
      {
        label: 'Opened',
        data: [5800, 8200, 6500, 9100, 8400, 3700, 2300],
        borderColor: '#107C10',
        backgroundColor: 'transparent',
        tension: 0.4,
      },
      {
        label: 'Clicked',
        data: [1300, 2200, 1800, 2500, 2100, 900, 600],
        borderColor: '#5C2D91',
        backgroundColor: 'transparent',
        tension: 0.4,
      },
    ],
  };

  // Engagement stats bar chart
  const engagementOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ${context.parsed.y}%`;
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          callback: function(value: any) {
            return value + '%';
          }
        }
      },
    },
    maintainAspectRatio: false,
  };

  const engagementData = {
    labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    datasets: [
      {
        label: 'Engagement Rate',
        data: [45, 52, 48, 61, 55, 42, 38],
        backgroundColor: 'rgba(0, 120, 212, 0.7)',
        borderWidth: 0,
        borderRadius: 4,
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader className="pb-0">
          <CardTitle className="text-lg font-medium">Email Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <Line options={emailStatsOptions} data={emailStatsData} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-0">
          <CardTitle className="text-lg font-medium">Daily Engagement Rate</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <Bar options={engagementOptions} data={engagementData} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChartStats;